/**
 * Created by jinyihua on 2016/12/3.
 */

$(function () {

    $(".loginSubmit").unbind('click').click(function(){
        var $frmElement = $("<form />");
        $frmElement.append()
    });



})
