package com.cunho.model;

/**
 * Created by jinyihua on 2016/12/3.
 */
public class DiaryTypeVO {

    private int DIARYTYPEID;
    private String TYPENAME = "";

    public int getDIARYTYPEID() {
        return DIARYTYPEID;
    }

    public void setDIARYTYPEID(int DIARYTYPEID) {
        this.DIARYTYPEID = DIARYTYPEID;
    }

    public String getTYPENAME() {
        return TYPENAME;
    }

    public void setTYPENAME(String TYPENAME) {
        this.TYPENAME = TYPENAME;
    }

    @Override
    public String toString() {
        return "DiaryTypeVO{" +
                "DIARYTYPEID=" + DIARYTYPEID +
                ", TYPENAME='" + TYPENAME + '\'' +
                '}';
    }
}
