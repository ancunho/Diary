package com.cunho.model;

/**
 * Created by jinyihua on 2016/12/3.
 */
public class UserVO {

    private int USERID;
    private String USERNAME;
    private String PASSWORD;
    private String NICKNAME;
    private String IMAGEPATH;
    private String MOOD;

    public int getUSERID() {
        return USERID;
    }

    public void setUSERID(int USERID) {
        this.USERID = USERID;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getNICKNAME() {
        return NICKNAME;
    }

    public void setNICKNAME(String NICKNAME) {
        this.NICKNAME = NICKNAME;
    }

    public String getIMAGEPATH() {
        return IMAGEPATH;
    }

    public void setIMAGEPATH(String IMAGEPATH) {
        this.IMAGEPATH = IMAGEPATH;
    }

    public String getMOOD() {
        return MOOD;
    }

    public void setMOOD(String MOOD) {
        this.MOOD = MOOD;
    }

    @Override
    public String toString() {
        return "USERVO{" +
                "USERID=" + USERID +
                ", USERNAME='" + USERNAME + '\'' +
                ", PASSWORD='" + PASSWORD + '\'' +
                ", NICKNAME='" + NICKNAME + '\'' +
                ", IMAGEPATH='" + IMAGEPATH + '\'' +
                ", MOOD='" + MOOD + '\'' +
                '}';
    }

}
