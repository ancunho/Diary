package com.cunho.model;

/**
 * Created by jinyihua on 2016/12/3.
 */
public class DiaryVo {

    private int DIARYID;
    private String TITLE;
    private String CONTENT;
    private String TYPEID;
    private String CREATETIME;

    public int getDIARYID() {
        return DIARYID;
    }

    public void setDIARYID(int DIARYID) {
        this.DIARYID = DIARYID;
    }

    public String getTITLE() {
        return TITLE;
    }

    public void setTITLE(String TITLE) {
        this.TITLE = TITLE;
    }

    public String getCONTENT() {
        return CONTENT;
    }

    public void setCONTENT(String CONTENT) {
        this.CONTENT = CONTENT;
    }

    public String getTYPEID() {
        return TYPEID;
    }

    public void setTYPEID(String TYPEID) {
        this.TYPEID = TYPEID;
    }

    public String getCREATETIME() {
        return CREATETIME;
    }

    public void setCREATETIME(String CREATETIME) {
        this.CREATETIME = CREATETIME;
    }

    @Override
    public String toString() {
        return "DiaryVo{" +
                "DIARYID=" + DIARYID +
                ", TITLE='" + TITLE + '\'' +
                ", CONTENT='" + CONTENT + '\'' +
                ", TYPEID='" + TYPEID + '\'' +
                ", CREATETIME='" + CREATETIME + '\'' +
                '}';
    }
}
