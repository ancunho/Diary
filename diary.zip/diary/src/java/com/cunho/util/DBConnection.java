package com.cunho.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Created by jinyihua on 2016/12/3.
 */
public class DBConnection {


    /**
     * DB Connection
     * @return
     * @throws Exception
     */
    public Connection getConnection() throws Exception{
        Class.forName(PropertiesUtil.getValue("driverName"));
        Connection connection = DriverManager.getConnection(PropertiesUtil.getValue("url"), PropertiesUtil.getValue("username"),PropertiesUtil.getValue("password"));
        return connection;
    }

    /**
     * Close Connection
     * @param connection
     */
    public void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        DBConnection dbConnection = new DBConnection();
        try {
            dbConnection.getConnection();
            System.out.println("数据库连接成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
