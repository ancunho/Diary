package com.cunho.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Created by jinyihua on 2016/12/5.
 */
public class PropertiesUtil {

    public static String getValue(String key) {
        Properties properties = new Properties();
        InputStream inputStream = new PropertiesUtil().getClass().getResourceAsStream("/jdbc.properties");
        try {
            properties.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return (String) properties.get(key);
    }
}
