package com.cunho.util;

import sun.misc.BASE64Encoder;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Created by jinyihua on 2016/12/5.
 */
public class Md5Old {

    public static String EncoderPwdByMd5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        BASE64Encoder base64Encoder = new BASE64Encoder();
        return base64Encoder.encode(md5.digest(str.getBytes("UTF-8")));
    }

    public static void main(String[] args) throws Exception {
        System.out.println(EncoderPwdByMd5("cunho"));
    }
}
