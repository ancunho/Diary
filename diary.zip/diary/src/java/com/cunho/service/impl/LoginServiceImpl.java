package com.cunho.service.impl;

import com.cunho.model.UserVO;
import com.cunho.service.LoginService;
import com.cunho.util.Md5Old;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by jinyihua on 2016/12/3.
 */
public class LoginServiceImpl implements LoginService {


    public UserVO login(Connection connection, UserVO userVO){

        UserVO resultUser = null;
        StringBuffer sb = new StringBuffer();
        sb.append("SELECT * FROM USER WHERE USERNAME = ? AND PASSWORD = ?");
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sb.toString());
            preparedStatement.setString(1, userVO.getUSERNAME());
            preparedStatement.setString(2, Md5Old.EncoderPwdByMd5(userVO.getPASSWORD()));
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()) {
                resultUser = new UserVO();
                resultUser.setUSERNAME(rs.getString("USERNAME"));
                resultUser.setPASSWORD(rs.getString("PASSWORD"));
                resultUser.setNICKNAME(rs.getString("NICKNAME"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return resultUser;
    }



}
