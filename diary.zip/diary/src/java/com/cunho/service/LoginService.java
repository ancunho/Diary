package com.cunho.service;

import com.cunho.model.UserVO;

import java.sql.Connection;

/**
 * Created by jinyihua on 2016/12/3.
 */
public interface LoginService {

    public UserVO login(Connection connection,UserVO userVO);
}
